Rakk ikke � bli ferdig med en simpel kollisjonstest
Koden er ikke godt dokumentert :(

Men har 3D progresjon og fiender kommer mot deg :) Litt vel rotete gode men er noe jeg h�per � f� fikset p� til neste gang :)